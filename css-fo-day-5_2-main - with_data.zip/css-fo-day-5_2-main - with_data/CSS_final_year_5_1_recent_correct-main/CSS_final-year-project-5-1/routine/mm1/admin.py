from django.contrib import admin
from.models import *


#admin.site.register(Room)
admin.site.register(Instructor)
admin.site.register(MeetingTime)
admin.site.register(Course)
admin.site.register(Semester)
admin.site.register(Selectsemester)

